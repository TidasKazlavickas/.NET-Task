
CREATE TABLE employees (
    employeeid INT NOT NULL,
    employeename VARCHAR(128) NOT NULL,
    employeesalary INT NOT NULL
);
