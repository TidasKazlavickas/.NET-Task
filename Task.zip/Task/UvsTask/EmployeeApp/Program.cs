﻿using EmployeeApp.Models;

if (args.Length == 0)
{
    Console.WriteLine("No command provided.");
    return;
}

using var db = new AppDbContext();
await db.Database.EnsureCreatedAsync();

switch (args[0])
{
    case "set-employee":
        var empId = int.Parse(GetArg("--employeeId"));
        var name = GetArg("--employeeName");
        var salary = int.Parse(GetArg("--employeeSalary"));

        var existing = await db.Employees.FindAsync(empId);
        if (existing is null)
        {
            db.Employees.Add(new Employee
            {
                EmployeeId = empId,
                EmployeeName = name,
                EmployeeSalary = salary
            });
        }
        else
        {
            existing.EmployeeName = name;
            existing.EmployeeSalary = salary;
        }

        await db.SaveChangesAsync();
        Console.WriteLine("Employee saved.");
        break;

    case "get-employee":
        empId = int.Parse(GetArg("--employeeId"));
        var employee = await db.Employees.FindAsync(empId);
        if (employee is null)
        {
            Console.WriteLine("Employee not found.");
        }
        else
        {
            Console.WriteLine($"EmployeeId: {employee.EmployeeId}, Name: {employee.EmployeeName}, Salary: {employee.EmployeeSalary}");
        }
        break;

    default:
        Console.WriteLine("Unknown command.");
        break;
}

string GetArg(string key)
{
    var index = Array.IndexOf(args, key);
    if (index == -1 || index + 1 >= args.Length)
        throw new ArgumentException($"Argument {key} not found.");
    return args[index + 1];
}
