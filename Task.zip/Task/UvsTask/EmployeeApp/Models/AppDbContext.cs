using Microsoft.EntityFrameworkCore;

namespace EmployeeApp.Models
{
    public class AppDbContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Port=7777;Database=employee_db;Username=postgres;Password=guest");
        }
    }
}
